with base as (
    select
    *,
    {{ dbt_utils.generate_surrogate_key(['order_id', 'payment_sequential']) }} as payment_key
    from {{ ref('stg_order_payments') }}
),
order as (
    select
        order_id,
        order_key
    from {{ ref('fct_orders') }}
)
select
    b.payment_key,
    o.order_key,
    b.payment_sequential_id as payment_sequential,
    b.payment_type,
    b.payment_installments,
    b.payment_value
from base b
left join order o using (order_id)
