with order_payment_base as (

    select
    *,
    {{ dbt_utils.generate_surrogate_key(["order_id", "payment_sequential"]) }} AS order_payment_key,

    from {{ ref('stg_order_payments') }}
),fct_order_base as (

    select
        order_id,
        order_key
    from {{ ref('fct_orders') }}
)
select
    opb.order_payment_key,
    fob.order_key,
    opb.payment_sequential_id,
    opb.payment_type,
    opb.payment_installments,
    opb.payment_value
from order_payment_base opb
left join fct_order_base fob using (order_id)
